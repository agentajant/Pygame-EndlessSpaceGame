HOW  TO INSTALL

​=Requires python version 3.9.5 to play

= First run the Install_Import.bat file.

=Then run the game.bat file to play the game.